//
//  main.cpp
//  While Loops - Task 2
//  Using a while loop write a C++ program to compute the sum of number from 20 to 25.
//
//  Created by Victor Mwendwa on 11/16/21.
//
#include <iostream>
using namespace std;
int main ()
{
    int counter = 20;
    int sum = 0;
    while (counter<=25)
    {
        sum += counter;
        counter++;
    }
    cout<<"sum is: "<<sum;
    return 0;
}
