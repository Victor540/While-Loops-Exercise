//
//  main.cpp
//  While Loop - Task 1
//  Using the while loop, write a C++ program that outputs the numbers: 12,14,16,18,20,22,24,26,28.
//
//  Created by Vector Mwendwa on 11/18/21.
//
#include <iostream>
using namespace std;

int main(){
    int number = 12;
    
    
    while(number<=28){
    
    cout<< number<<",";
    number = number + 2;
        
    }
    

    
    return 0;
}
